#ifndef CUBE_H
#define CUBE_H

class Cube
{
private:
	unsigned int Handle;

public:
	Cube();

	void render();
};

#endif // CUBE_H