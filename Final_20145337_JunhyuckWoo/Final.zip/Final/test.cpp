#include "diging.h"
#include "plane.h"
#include "vbomesh.h"
#include "bmpreader.h"
#include <stdlib.h>

//--------------------------------------------------------------
//						    Define
//--------------------------------------------------------------
#define HEIGHT 800
#define WIDTH 800

#define XBASE 0
#define YBASE 0
#define ZBASE 2
#define ATX 0
#define ATY 0
#define ATZ 0
#define UPX 0
#define UPY 1
#define UPZ 0
//-------------------------------------------------------------

void startup();
void render();
void shutdown();
//--------------------------------------------------------------
//						 Extern Function
//--------------------------------------------------------------
extern void version();
extern GLuint compile_shaders(GLchar* vsource, GLchar* fsource);
//-------------------------------------------------------------
int cameraX = 0, cameraY = 0, cameraZ = 0;
int atX = 0, atY = 0, atZ = 0;

int option = 0;
int control = -1;
float camMov[10] = { 0, };
float i[3] = { 0.001, 0.003, 0.0005 };
float loc[4][300] = { 0, };
float mov[300] = { 0, };
float base[301] = { 0, };
float bgcR = 0.5976, bgcG = 0.84765, bgcB = 0.91406;

bool sun = false;
bool animation = false;

Plane *plane;
VBOMesh *palace;
VBOMesh *ground;
VBOMesh *mount;
VBOMesh *lantern1;
VBOMesh *lantern2;
VBOMesh *lantern3;

mat4 model;
mat4 view;
mat4 projection;

GLint color;
GLint mv_location;
GLint proj_location;
GLuint tex_object[20];
GLuint rendering_program;

void generate_texture(GLubyte * data, int width, int height)
{
	int x, y;
	for (y = 0; y < height; y++)
	{
		for (x = 0; x < width; x++)
		{
			GLubyte c = (((x & 0x8) == 0) ^ ((y & 0x8) == 0))*255.0;
			data[(y * width + x) * 4 + 0] = c;
			data[(y * width + x) * 4 + 1] = c;
			data[(y * width + x) * 4 + 2] = c;
			data[(y * width + x) * 4 + 3] = 1.0f;
		}
	}
}

void loadTexture()
{
	glActiveTexture(GL_TEXTURE0);
	tex_object[0] = BMPReader::loadTex("data/grass.bmp");
	glActiveTexture(GL_TEXTURE1);
	tex_object[1] = BMPReader::loadTex("data/card.bmp");
	glActiveTexture(GL_TEXTURE2);
	tex_object[2] = BMPReader::loadTex("data/sea.bmp");
	glActiveTexture(GL_TEXTURE3);
	tex_object[3] = BMPReader::loadTex("data/moss.bmp");
	glActiveTexture(GL_TEXTURE4);
	tex_object[4] = BMPReader::loadTex("data/rock1.bmp");
	glActiveTexture(GL_TEXTURE5);
	tex_object[5] = BMPReader::loadTex("data/rock2.bmp");
	glActiveTexture(GL_TEXTURE6);
	tex_object[6] = BMPReader::loadTex("data/lam.bmp");
	glActiveTexture(GL_TEXTURE7);
	tex_object[7] = BMPReader::loadTex("data/palace.bmp");
}

void modeling()
{
	plane = new Plane(13.0f, 11.0f, 1, 1);
	//palace = new VBOMesh("data/castle.obj", false, true, true);
	cout << "Castle is Loaded" << endl;
	//ground = new VBOMesh("data/field.obj", false, true, true);
	cout << "Field is Loaded" << endl;
	//mount = new VBOMesh("data/mountain.obj", false, true, true);
	cout << "Mountain is Loaded" << endl;
	lantern1 = new VBOMesh("data/lantern3.obj", false, true, true);
}

void startup()
{
	/******* OpenGL Initialization */
	glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LEQUAL); //Passes if the incoming depth value is less than or
	/**** Shaders as variables */
	rendering_program = compile_shaders("v.glsl", "f.glsl");
	glUseProgram(rendering_program);

	// modeling
	modeling();

	// viewing
	model = mat4(1.0);
	view = LookAt(vec3(XBASE, YBASE, ZBASE), vec3(ATX, 0.75f, ATY), vec3(UPX, UPY, UPZ));
	projection = Perspective(70.0f, (float)WIDTH / HEIGHT, 0.01f, 100.0f);
	mv_location = glGetUniformLocation(rendering_program, "mv_matrix");
	proj_location = glGetUniformLocation(rendering_program, "proj_matrix");
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	glUniformMatrix4fv(proj_location, 1, GL_TRUE, projection);

	// Texture
	loadTexture();

	for (int k = 0; k < 4; k++)
	{
		for (int i = 0; i < 300;)
		{
			float buf = ((rand() % 50000) / 1000.0);
			if (buf < 10)
			{
				loc[k][i] = buf - 5;
				i++;
				if (k < 2)
					loc[k][i] *= -1;
				mov[i] = buf / 5000.0;
			}
		}
	}
}

void idle(){
	if (animation)
	{
		for (int i = 0; i < 300; i++)
		{
			base[i] += mov[i];
		}
	}
	if (base[0]> 50)
	{
		for (int i = 0; i < 300; i++)
		{
			base[i] = 1.0;
			animation = false;
		}
	}
	glutPostRedisplay();
}

void Palace()
{
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ka"), 0.9f, 0.9f, 0.9f);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Kd"), 0.7f, 0.7f, 0.7f);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ks"), 0.1f, 0.1f, 0.1f);
	glUniform1f(glGetUniformLocation(rendering_program, "Material.Shininess"), 180.0f);
	glUniform1i(glGetUniformLocation(rendering_program, "Tex"), 7);
	model = mat4(1.0); model *= Translate(vec3(-3, 0, -3));
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	palace->render();
}

void Field()
{
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ka"), 0.9f, 0.9f, 0.9f);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Kd"), 0.7f, 0.7f, 0.7f);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ks"), 0.1f, 0.1f, 0.1f);
	glUniform1f(glGetUniformLocation(rendering_program, "Material.Shininess"), 180.0f);
	glUniform1i(glGetUniformLocation(rendering_program, "Tex"), 0);
	model = mat4(1.0); model *= Rotate(90, vec3(0.0, 1.0, 0.0));
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	ground->render();
}

void render()
{
	control = 1;
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(bgcR, bgcG, bgcB, 1);
	glUseProgram(rendering_program);

	// Lighting
	glUniform3f(glGetUniformLocation(rendering_program, "Light.Intensity"), 1, 1, 1);
	//glUniform4fv(glGetUniformLocation(rendering_program, "Light.Position"),	1, view*vec4(10.0f, 10.0, 10.0f, 1.0));
	view = LookAt(vec3(XBASE + camMov[0], YBASE + camMov[1], ZBASE + camMov[2]), vec3(ATX + camMov[0], ATY + camMov[1], ATZ + camMov[2]), vec3(UPX, UPY, UPZ));

	/********Object  */
	//Palace();
	//Field();

	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ka"), 0.9f, 0.9f, 0.9f);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Kd"), 0.7f, 0.7f, 0.7f);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ks"), 0.1f, 0.1f, 0.1f);
	glUniform1f(glGetUniformLocation(rendering_program, "Material.Shininess"), 180.0f);
	glUniform1i(glGetUniformLocation(rendering_program, "Tex"), 2);
	model = mat4(1.0); model *= Translate(0.0, -0.1, 0.0) * Rotate(90, vec3(0.0, 1.0, 0.0));
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	plane->render();

	glUniform1i(glGetUniformLocation(rendering_program, "Tex"), 4);
	model = mat4(1.0); model *= Translate(0.0, -0.1, -12.0);
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	//mount->render();
	glUniform1i(glGetUniformLocation(rendering_program, "Tex"), 5);
	model = mat4(1.0); model *= Translate(-10.8, -0.1, 0) * Rotate(90, vec3(0, 1, 0));
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	//mount->render();
	model = mat4(1.0); model *= Translate(10.8, -0.1, 0) * Rotate(-90, vec3(0, 1, 0));
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	//mount->render();

	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ka"), 1, 1, 1);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Kd"), 1, 1, 1);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ks"), 1, 1, 1);
	glUniform1f(glGetUniformLocation(rendering_program, "Material.Shininess"), 180.0f);
	if (sun)
	{
		glUniform3f(glGetUniformLocation(rendering_program, "Light.Intensity"), 0.5, 0.5, 0.5);
		glUniform1i(glGetUniformLocation(rendering_program, "Tex"), 6);
		for (int i = 0; i < 300; i++)
		{
			glUniform4fv(glGetUniformLocation(rendering_program, "Light.Position"), 1, view*vec4(loc[0][i], base[i] + 2, loc[1][i], 1.0));
			model = mat4(1.0); model *= Translate(vec3(loc[0][i], base[i], loc[1][i]));
			glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
			lantern1->render();
		}
		for (int i = 0; i < 300; i++)
		{
			glUniform4fv(glGetUniformLocation(rendering_program, "Light.Position"), 1, view*vec4(loc[2][i], base[i], loc[3][i], 1.0));
			model = mat4(1.0); model *= Translate(vec3(loc[2][i], base[i], loc[3][i]));
			glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
			lantern1->render();
		}
	}

	glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'N': case 'n':
		bgcR = 0.17, bgcG = 0.21, bgcB = 0.394;
		sun = true;
		break;
	case 'D': case 'd':
		bgcR = 0.5976, bgcG = 0.84765, bgcB = 0.91406;
		sun = false; animation = false;
		break;
	case 'A': case 'a':
		break;
	case 'S': case 's':
		animation = true;
		break;
	case 'R': case 'r':
		for (int i = 0; i < 10; i++)
			camMov[i] = 0;
		break;
	case '1':		option = 1;		break;
	case '2':		option = 2;		break;
	case '3':		option = 3;		break;
	case '4':		option = 4;		break;
	case '+':		camMov[option] += 1;		break;
	case '-':		camMov[option] -= 1;		break;
	default:
		break;
	}
}

void shutdown()
{
	glDeleteProgram(rendering_program);
}

int main(int argc, char **argv)
{
	srand((unsigned)time(NULL));
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(WIDTH, HEIGHT);
	glutCreateWindow("Final");
	glewInit();

	version();
	startup();
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(render);
	glutIdleFunc(idle);

	glutMainLoop();
	shutdown();
	return 0;
}