#include "diging.h"
#include "plane.h"
#include "vbomesh.h"
#include "bmpreader.h"
#include <stdlib.h>

//--------------------------------------------------------------
//						    Define
//--------------------------------------------------------------
#define HEIGHT 800
#define WIDTH 800

#define XBASE 0
#define YBASE 0.75
#define ZBASE 0
#define ATX -3
#define ATY 0.75
#define ATZ -3
#define UPX 0
#define UPY 1
#define UPZ 0
//-------------------------------------------------------------

//--------------------------------------------------------------
//						    Function
//--------------------------------------------------------------
void startup();
void render();
void shutdown();
inline float randFloat() { return ((float)rand() / RAND_MAX); }
inline float mix(float x, float y, float a) { return ((1.0 - a)*x + a*y); }

//-------------------------------------------------------------

//--------------------------------------------------------------
//						 Extern Function
//--------------------------------------------------------------
extern void version();
extern GLuint compile_shaders(GLchar* vsource, GLchar* fsource);
//-------------------------------------------------------------

//-------------------------------------------------------------
//						Global Variable
//-------------------------------------------------------------

// Options
int option = 0;
int control = 1;
float bgcR = 0.5976, bgcG = 0.84765, bgcB = 0.91406;

// Transformation
bool trans, rotat, s;
float cam_cen_x = 0, cam_cen_y = 0;
float trans_x = 0, trans_y = 0, scale = 0, viewing = 50;
float rot_x = 0, rot_y = 0, rot_z = 0, buf_x = 0, buf_y = 0, buf_z = 0;
float mouseX, mouseY, pmouseX, pmouseY;
float camMov[10] = { 0, };

// Particle
float t = 0;
GLuint initVel, startTime, particles;
GLuint nParticles;

// Animation
bool sun = true;
bool animation = false;
bool snow = false;
float angle = 0;
float angle2 = 0;
float atx = 0, aty = 0, atz = 0;
float xbase = 0, ybase = 0, zbase = 0;
float loc[4][300] = { 0, };
float mov[300] = { 0, };
float base[300] = { 0, };

// Object
Plane *plane;
VBOMesh *palace;
VBOMesh *ground;
VBOMesh *mount;
VBOMesh *lantern;

// Matirx
mat4 model;
mat4 view;
mat4 projection;

GLint color;
GLint mv_location;
GLint proj_location;
GLuint tex_object[20];
GLuint rendering_program;
//-------------------------------------------------------------


void generate_texture(GLubyte * data, int width, int height)
{
	int x, y;
	for (y = 0; y < height; y++)
	{
		for (x = 0; x < width; x++)
		{
			GLubyte c = (((x & 0x8) == 0) ^ ((y & 0x8) == 0))*255.0;
			data[(y * width + x) * 4 + 0] = c;
			data[(y * width + x) * 4 + 1] = c;
			data[(y * width + x) * 4 + 2] = c;
			data[(y * width + x) * 4 + 3] = 1.0f;
		}
	}
}

void initBuffers()
{
	nParticles = 80000;

	// Generate the buffers 
	glGenBuffers(1, &initVel);   // Initial velocity buffer 
	glGenBuffers(1, &startTime); // Start time buffer 

	// Allocate space for all buffers 
	int size = nParticles * 3 * sizeof(float);
	glBindBuffer(GL_ARRAY_BUFFER, initVel);
	glBufferData(GL_ARRAY_BUFFER, size, NULL, GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, startTime);
	glBufferData(GL_ARRAY_BUFFER, nParticles * sizeof(float), NULL, GL_STATIC_DRAW);

	// Fill the first velocity buffer with random velocities 
	vec3 v(0.0f);
	float velocity, theta, phi;
	GLfloat *data = new GLfloat[nParticles * 3];
	for (unsigned int i = 0; i < nParticles; i++) {
		theta = mix(0.0f, (float)M_PI / 6.0f, randFloat());
		phi = mix(0.0f, (float)2 * M_PI, randFloat());
		v.x = sinf(theta) * cosf(phi);
		v.y = cosf(theta);
		v.z = sinf(theta) * sinf(phi);
		velocity = mix(1.25f, 1.5f, randFloat());
		v = normalize(v) * velocity;

		data[3 * i] = v.x * 1000;
		data[3 * i + 1] = v.y + 100;
		data[3 * i + 2] = v.z * 1000;
	}
	glBindBuffer(GL_ARRAY_BUFFER, initVel);
	glBufferSubData(GL_ARRAY_BUFFER, 0, size, data);
	delete[] data;

	// Fill the start time buffer 
	float *data1 = new GLfloat[nParticles];
	float time = 0.0f;
	float rate = 0.000075f;
	for (unsigned int i = 0; i < nParticles; i++) {
		data1[i] = time;
		time += rate;
	}

	glBindBuffer(GL_ARRAY_BUFFER, startTime);
	glBufferSubData(GL_ARRAY_BUFFER, 0, nParticles * sizeof(float), data1);

	glBindBuffer(GL_ARRAY_BUFFER, 0);
	delete[] data1;

	// Attach these to the torus's vertex array 
	glGenVertexArrays(1, &particles);
	glBindVertexArray(particles);

	glBindBuffer(GL_ARRAY_BUFFER, initVel);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, NULL);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, startTime);
	glVertexAttribPointer(1, 1, GL_FLOAT, GL_FALSE, 0, NULL);
	glEnableVertexAttribArray(1);
}

void loadTexture()
{
	// Field
	glActiveTexture(GL_TEXTURE0);
	tex_object[0] = BMPReader::loadTex("data/grass.bmp");
	glActiveTexture(GL_TEXTURE1);
	tex_object[1] = BMPReader::loadTex("data/card.bmp");
	// Liver
	glActiveTexture(GL_TEXTURE2);
	tex_object[2] = BMPReader::loadTex("data/sea.bmp");
	// Mountain
	glActiveTexture(GL_TEXTURE3);
	tex_object[3] = BMPReader::loadTex("data/moss.bmp");
	glActiveTexture(GL_TEXTURE4);
	tex_object[4] = BMPReader::loadTex("data/snow.bmp");
	glActiveTexture(GL_TEXTURE5);
	tex_object[5] = BMPReader::loadTex("data/rock.bmp");
	// Lamp
	glActiveTexture(GL_TEXTURE6);
	tex_object[6] = BMPReader::loadTex("data/lam.bmp");
	// Palace
	glActiveTexture(GL_TEXTURE7);
	tex_object[7] = BMPReader::loadTex("data/palace.bmp");
	// Particle
	glActiveTexture(GL_TEXTURE8);
	tex_object[8] = BMPReader::loadTex("data/particle.bmp");
}

void modeling()
{
	plane = new Plane(13.0f, 11.0f, 1, 1); cout << "Liver is Loaded" << endl;
	palace = new VBOMesh("data/castle.obj", false, true, true); cout << "Castle is Loaded" << endl;
	ground = new VBOMesh("data/field.obj", false, true, true); cout << "Field is Loaded" << endl;
	mount = new VBOMesh("data/mountain.obj", false, true, true); cout << "Mountain is Loaded" << endl;
	lantern = new VBOMesh("data/lantern3.obj", false, true, true); cout << "lantern is Loaded" << endl;
}

void lanternLocation()
{
	for (int k = 0; k < 4; k++)
	{
		for (int i = 0; i < 300;)
		{
			float buf = ((rand() % 50000) / 1000.0);
			if (buf < 10)
			{
				loc[k][i] = buf - 5;
				i++;
				if (k < 2)
					loc[k][i] *= -1;
				mov[i] = buf / 5000.0;
			}
		}
	}
}

void spotLight()
{
	glUniform3f(glGetUniformLocation(rendering_program, "Spot.Intensity"), 0.9, 0.9, 0.9);
	glUniform1f(glGetUniformLocation(rendering_program, "Spot.exponent"), 3.0f);
	glUniform1f(glGetUniformLocation(rendering_program, "Spot.cutoff"), 14.0f);

	vec4 lightPos = vec4(0, 0.75f, 0, 1.0f);
	//vec4 lightPos = vec4(5.0f * cos(angle), 15.0f, 15.0f * sin(angle), 1.0f);

	vec4 direction = view*vec4(7 * cos(radians(angle)), 0.0, 7 * sin(radians(angle)), 1.0);
	glUniform4fv(glGetUniformLocation(rendering_program, "Spot.Position"), 1, lightPos);
	glUniform3f(glGetUniformLocation(rendering_program, "Spot.direction"), direction[0], direction[1], direction[2]);
}

void startup()
{
	/******* OpenGL Initialization */
	glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LEQUAL); //Passes if the incoming depth value is less than or
	/**** Shaders as variables */
	rendering_program = compile_shaders("v.glsl", "f.glsl");
	glUseProgram(rendering_program);

	// modeling
	modeling();

	// viewing
	model = mat4(1.0);
	view = LookAt(vec3(XBASE, YBASE, ZBASE), vec3(ATX, ATY, ATZ), vec3(UPX, UPY, UPZ));
	projection = Perspective(70.0f, (float)WIDTH / HEIGHT, 0.01f, 100.0f);
	mv_location = glGetUniformLocation(rendering_program, "mv_matrix");
	proj_location = glGetUniformLocation(rendering_program, "proj_matrix");
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	glUniformMatrix4fv(proj_location, 1, GL_TRUE, projection);

	// Generate our vertex buffers
	//initBuffers();

	// Texture
	loadTexture();

	// Light
	spotLight();
	

	// Set lantern location
	lanternLocation();
}

void idle(){
	angle2+=0.01;
	angle = -135 + 22.5*sin(angle2);
	// Morning
	if (sun)
	{
		// Camera moving
		if (animation)
		{
			ybase += 0.005; zbase += 0.005;
			atx += 0.0025; atz += 0.0025;
		}
		if (ybase >= 6)
		{
			animation = false;
		}
		if (snow)
		{
			t += 0.02;
		}
	}
	else
	{
		if (animation)
		{
			ybase += 0.002; zbase += 0.002;
			atx += 0.001; atz += 0.001;
			for (int i = 0; i < 300; i++)
			{
				base[i] += mov[i];
			}
		}

		if (base[0]> 50)
		{
			for (int i = 0; i < 300; i++)
			{
				base[i] = 0.1;
				animation = false;
			}
		}
		if (ybase >= 6)
		{
			ybase -= 0.002; zbase -= 0.002;
			atx -= 0.001; atz -= 0.001;
		}
	}
	glutPostRedisplay();
}

void Palace()
{
	if (sun)
		glUniform1d(glGetUniformLocation(rendering_program, "control"), 4);
	else
		glUniform1d(glGetUniformLocation(rendering_program, "control"), 8);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ka"), 0.9f, 0.9f, 0.9f);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Kd"), 0.7f, 0.7f, 0.7f);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ks"), 0.1f, 0.1f, 0.1f);
	glUniform1f(glGetUniformLocation(rendering_program, "Material.Shininess"), 180.0f);
	glUniform1i(glGetUniformLocation(rendering_program, "Tex"), 7);
	model = mat4(1.0); model *= Translate(vec3(-3, 0, -3));
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	glUniform4fv(glGetUniformLocation(rendering_program, "Light.Position"), 1, view*vec4(5 * cos(radians(angle)), 1, 5 * sin(radians(angle)), 1.0));
	palace->render();
}
void Field()
{
	if (sun)
	{
		glUniform1d(glGetUniformLocation(rendering_program, "control"), 2);
		glUniform1i(glGetUniformLocation(rendering_program, "Tex"), 0);
		glUniform1i(glGetUniformLocation(rendering_program, "Add"), 4);
	}
	else
	{
		glUniform1d(glGetUniformLocation(rendering_program, "control"), 5);
		glUniform1i(glGetUniformLocation(rendering_program, "Tex"), 0);
	}
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ka"), 0.9f, 0.9f, 0.9f);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Kd"), 0.7f, 0.7f, 0.7f);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ks"), 0.1f, 0.1f, 0.1f);
	glUniform1f(glGetUniformLocation(rendering_program, "Material.Shininess"), 180.0f);
	model = mat4(1.0); model *= Rotate(90, vec3(0.0, 1.0, 0.0));
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	ground->render();
}
void Liver()
{
	glUniform1d(glGetUniformLocation(rendering_program, "control"), 1);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ka"), 0.9f, 0.9f, 0.9f);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Kd"), 0.7f, 0.7f, 0.7f);
	glUniform3f(glGetUniformLocation(rendering_program, "Material.Ks"), 0.1f, 0.1f, 0.1f);
	glUniform1f(glGetUniformLocation(rendering_program, "Material.Shininess"), 180.0f);
	glUniform1i(glGetUniformLocation(rendering_program, "Tex"), 2);
	model = mat4(1.0); model *= Translate(0.0, -0.03, 0.0) * Rotate(90, vec3(0.0, 1.0, 0.0));
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	plane->render();
}
void Mountain()
{
	glUniform1d(glGetUniformLocation(rendering_program, "control"), 2);
	glUniform1i(glGetUniformLocation(rendering_program, "Tex"), 5);
	if (sun)
		glUniform1i(glGetUniformLocation(rendering_program, "Add"), 4);
	else
		glUniform1i(glGetUniformLocation(rendering_program, "Add"), 3);
	model = mat4(1.0); model *= Translate(0.0, -0.1, -11.0)* Rotate(180, vec3(0, 1, 0));
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	mount->render();
	model = mat4(1.0); model *= Translate(-9.3, -0.1, 0) * Rotate(-90, vec3(0, 1, 0));
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	mount->render();
	model = mat4(1.0); model *= Translate(9.3, -0.1, 0) * Rotate(90, vec3(0, 1, 0));
	glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
	mount->render();
}
void Lantern()
{
	if (!sun)
	{
		glUniform3f(glGetUniformLocation(rendering_program, "Material.Ka"), 1, 1, 1);
		glUniform3f(glGetUniformLocation(rendering_program, "Material.Kd"), 1, 1, 1);
		glUniform3f(glGetUniformLocation(rendering_program, "Material.Ks"), 1, 1, 1);
		glUniform1f(glGetUniformLocation(rendering_program, "Material.Shininess"), 180.0f);
		glUniform1d(glGetUniformLocation(rendering_program, "control"), 3);
		glUniform3f(glGetUniformLocation(rendering_program, "Light.Intensity"), 0.5, 0.5, 0.5);
		glUniform1i(glGetUniformLocation(rendering_program, "Tex"), 6);
		for (int i = 0; i < 300; i++)
		{
			glUniform4fv(glGetUniformLocation(rendering_program, "Light.Position"), 1, view*vec4((loc[0][i], base[i], loc[1][i]),1.0));
			model = mat4(1.0); model *= Translate(vec3(loc[0][i], base[i], loc[1][i]));
			glUniformMatrix4fv(mv_location, 1, GL_TRUE, view*model);
			lantern->render();
		}
	}
}
void render()
{
	// Base Setting
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(bgcR, bgcG, bgcB, 1);
	glUseProgram(rendering_program);

	// For mouse moving
	projection = Perspective(70.0f-scale, (float)WIDTH / HEIGHT, 0.01f, 100.0f);
	proj_location = glGetUniformLocation(rendering_program, "proj_matrix");
	glUniformMatrix4fv(proj_location, 1, GL_TRUE, projection);
	view = LookAt(
		vec3(XBASE - cam_cen_x - trans_x + xbase + camMov[1], YBASE - cam_cen_y - trans_y + ybase + camMov[2], ZBASE + zbase), 
		vec3(ATX - cam_cen_x - trans_x + atx + camMov[1], ATY - cam_cen_y - trans_y + aty + camMov[2], ATZ + atz),
		vec3(UPX, UPY, UPZ)
		);
	view = view*Rotate(-rot_y - buf_y, vec3(1, 0, 0));
	view = view*Rotate(rot_x + buf_x, vec3(0, 1, 0));

	// Lighting
	glUniform3f(glGetUniformLocation(rendering_program, "Light.Intensity"), 1, 1, 1);

	// Spot Light
	spotLight();

	// Object
	Palace();
	Field();
	Liver();
	Mountain();
	Lantern();

	glutSwapBuffers();
}

void move(int x, int y)
{
	pmouseX = (float)x / (float)WIDTH*2.0 - 1.0;
	pmouseY = -(float)y / (float)HEIGHT*2.0 + 1.0;
	if (pmouseX >= 1)
		pmouseX = 1;
	else if (pmouseX <= -1)
		pmouseX = -1;
	if (pmouseY >= 1)
		pmouseY = 1;
	else if (pmouseY <= -1)
		pmouseY = -1;
	if (trans)
	{
		trans_x = 5 * (pmouseX - mouseX);
		trans_y = 5 * (pmouseY - mouseY);
	}
	if (s)
	{
		scale = 10 * (pmouseX - mouseX);
	}
	if (rotat)
	{
		buf_x = 100 * (pmouseX - mouseX);
		buf_x = 10 * radians(buf_x);
		buf_y = 100 * (pmouseY - mouseY);
		buf_y = 10 * radians(buf_y);
	}
}

void mouse(int button, int state, int x, int y)
{
	mouseX = (float)x / (float)WIDTH*2.0 - 1.0;
	mouseY = -(float)y / (float)HEIGHT*2.0 + 1.0;

	if (button == GLUT_MIDDLE_BUTTON && state == GLUT_DOWN)
	{
		trans = true;
	}
	else if (button == GLUT_MIDDLE_BUTTON && state == GLUT_UP)
	{
		cam_cen_x += trans_x; cam_cen_y += trans_y;
		trans = false;
	}

	else if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		rotat = true;
	}
	else if (button == GLUT_LEFT_BUTTON && state == GLUT_UP)
	{
		rot_x += buf_x;
		rot_y += buf_y;
		rotat = false;
	}
	else if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		s = true;
	}
	else if (button == GLUT_RIGHT_BUTTON && state == GLUT_UP)
	{
		view -= scale;
		s = false;
	}
	trans_x = 0; trans_y = 0;
	buf_x = 0, buf_y = 0;
	mouseX = 0, mouseY = 0, pmouseX = 0, pmouseY = 0;
	glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'N': case 'n':
		for (int i = 0; i < 300; i++)
			base[i] = 0.1;
		atx = 0, aty = 0, atz = 0;
		xbase = 0, ybase = 0, zbase = 0;
		bgcR = 0.17, bgcG = 0.21, bgcB = 0.394;
		sun = false; animation = false;
		break;
	case 'D': case 'd':
		for (int i = 0; i < 300; i++)
			base[i] = 0.1;
		atx = 0, aty = 0, atz = 0;
		xbase = 0, ybase = 0, zbase = 0;
		bgcR = 0.5976, bgcG = 0.84765, bgcB = 0.91406;
		sun = true; animation = false;
		break;
	case 'A': case 'a':
		animation = true;
		break;
	case 'S': case 's':
		snow = !snow;
		break;
	case 'R': case 'r':
		cam_cen_x = 0, cam_cen_y = 0;
		trans_x = 0, trans_y = 0, scale = 0, viewing = 50;
		rot_x = 0, rot_y = 0, rot_z = 0, buf_x = 0, buf_y = 0, buf_z = 0;
		mouseX, mouseY, pmouseX, pmouseY;
		atx = 0, aty = 0, atz = 0;
		xbase = 0, ybase = 0, zbase = 0;
		for (int i = 0; i < 10; i++)
			camMov[i] = 0;
		break;
	case 'Q': case 'q': case 033:
		exit(EXIT_SUCCESS);
		break;
	case '1':		option = 1;		break;
	case '2':		option = 2;		break;
	case '3':		option = 3;		break;
	case '4':		option = 4;		break;
	case '+':		camMov[option] += 1;		break;
	case '-':		camMov[option] -= 1;		break;
	default:
		break;
	}
}

void shutdown()
{
	glDeleteProgram(rendering_program);
}

int main(int argc, char **argv)
{
	srand((unsigned)time(NULL));
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(WIDTH, HEIGHT);
	glutCreateWindow("Final");
	glewInit();

	version();
	startup();
	glutMouseFunc(mouse);
	glutMotionFunc(move);
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(render);
	glutIdleFunc(idle);

	glutMainLoop();
	shutdown();
	return 0;
}